# 3 Metode Login SC
````php
1. Token FB AEEB
2. Convert Cookie ke Token AEEB
````
# Fitur Crack
````php
01. Crack Teman Publik
02. Crack Random ID Massal
03. Setting User Agent
04. Checkpoint Detedtor
05. Cek Hasil Crack
06. Info (Provider, Jaringan, Divace)
07. Info Update & Upgrade SC
00. Logout (Hapus Cookie)
````
# Tampilan Result Crack
````php
[OK] ID|PwFB
Cookie FB : 
Web & Aplikasi AKTIF

[OK] ID|PwFb
Cookie FB :
````
# Metode Crack
````php
Metode 1 Simpel (OK & CP)
Metode 2 ON Cookoe (OK & CP)
Metode 3 ON Cookie & Apk (OK & CP)
Metode 4 Simpel (OK Only)
Metode 5 ON Cookie (OK Only)
Metode 6 ON Cookie & Apk (OK Only)
````
# Sandi Otomoatis
````php
nama
nama lengkap
nama123
nama12345
````
# Perintah Menjalankan SC
````php
$ pkg update && pkg upgrade
$ pkg install python git
$ pip install requests bs4 futures
$ pip install cython
$ rm -rf meta
$ termux-setup-storage
$ git clone https://github.com/ROY-ID/meta
$ cd meta
$ git pull
$ python run.py
````
